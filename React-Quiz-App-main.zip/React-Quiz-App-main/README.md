# React-Quiz-App
A repo for quiz Application using react js and CSS

<h1>Quiz App Version 1</h1>
<h4><a href="https://youtu.be/hdd6SsssfOM">Video tutorial in Hindi</a></h4><br>
<div>
  <img width="375" height="375" alt="image" src="https://user-images.githubusercontent.com/36126362/215242543-8e096031-58af-47ae-b7eb-df910973f7fe.png">
  <img width="375" height="375" alt="image" src="https://user-images.githubusercontent.com/36126362/215242642-f56c250a-d3e2-45cc-8ac2-3c6350d25e6e.png">
</div>

